<?php

azp_add_element(
    'app_listings',
    array(
        'name'                    => __('Listings', 'easybook-mobile'),
        'category'                => 'Mobile App',
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => false,
        'showTypographyTab'       => false,
        'showAnimationTab'        => false,
        'template_folder'         => 'apps/',
        'is_section'              => true,
        'attrs'                   => array(
            array(
                'type'       => 'text',
                'param_name' => 'title',
                'label'      => __('Title', 'easybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'Discover featured listings',
                'show_in_admin' => true,
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_view_all',
                'label'         => __('Show View all?', 'easybook-mobile'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-mobile'),
                    'no'  => __('No', 'easybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'viewall_text',
                'label'      => __('View all text', 'easybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'View all',
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'ele_layout',
                'show_in_admin' => true,
                'label'         => __('Layout', 'easybook-mobile'),
                'default'       => 'slider',
                'value'         => array(
                    'slider'    => __('Slider', 'easybook-mobile'),
                    'carousel'  => __('Carousel', 'easybook-mobile'),
                    'list'      => __('List', 'easybook-mobile'),
                    'grid'      => __('Grid', 'easybook-mobile'),
                ),
            ),

            

            array(
                'type'       => 'text',
                'param_name' => 'cat_ids',
                'label'      => __('Listing Categories', 'easybook-mobile'),
                'desc'       => __( "Enter listing category's ids to get listings from, separated by a comma (,).", 'easybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'loc_ids',
                'label'      => __('Listing Locations', 'easybook-mobile'),
                'desc'       => __( "Enter listing location's ids to get listings from, separated by a comma (,).", 'easybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'tag_ids',
                'label'      => __('Listing Tags', 'easybook-mobile'),
                'desc'       => __( "Enter listing tag's ids to get listings from, separated by a comma (,).", 'easybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'ids',
                'label'      => __('Enter Listing IDs', 'easybook-mobile'),
                'desc'       => __( 'Enter Post ids to show, separated by a comma (,). Leave empty to show all.', 'easybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'ids_not',
                'label'      => __('Or Post IDs to Exclude', 'easybook-mobile'),
                'desc'       => __( 'Enter post ids to exclude, separated by a comma (,). Use if the field above is empty.', 'easybook-mobile' ),
                'default'    => '',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'featured_only',
                'show_in_admin' => true,
                'label'         => __('Show featured listings only?', 'easybook-mobile'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-mobile'),
                    'no'  => __('No', 'easybook-mobile'),
                ),
            ),

            

            array(
                'type'          => 'select',
                'param_name'    => 'orderby',
                'show_in_admin' => true,
                'label'         => __('Order by', 'easybook-mobile'),
                'default'       => 'date',
                'value'         => array(

                    'date' => esc_html__('Date', 'easybook-mobile'), 
                    'ID' => esc_html__('ID', 'easybook-mobile'), 
                    'author' => esc_html__('Author', 'easybook-mobile'), 
                    'title' => esc_html__('Title', 'easybook-mobile'), 
                    'modified' => esc_html__('Modified', 'easybook-mobile'),
                    'rand' => esc_html__('Random', 'easybook-mobile'),
                    'comment_count' => esc_html__('Comment Count', 'easybook-mobile'),
                    'menu_order' => esc_html__('Menu Order', 'easybook-mobile'),
                    'post__in' => esc_html__('ID order given (post__in)', 'easybook-mobile'),
                    'listing_featured' => esc_html__('Listing Featured', 'easybook-mobile'),
                ),
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'order',
                'show_in_admin' => true,
                'label'         => __('Sort Order', 'easybook-mobile'),
                'default'       => 'DESC',
                'value'         => array(
                    'ASC'  => __('Ascending', 'easybook-mobile'),
                    'DESC' => __('Descending', 'easybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'posts_per_page',
                'label'      => __('Posts to show', 'easybook-mobile'),
                'desc'       => __( 'Number of posts to show (-1 for all).', 'easybook-mobile' ),
                'default'    => '12',
            ),
            

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_id',
            //     'label'      => __('Element ID', 'easybook-mobile'),
            //     // 'desc'                  => '',
            //     'default'    => '',
            // ),

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_class',
            //     'label'      => __('Extra Class', 'easybook-mobile'),
            //     'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-mobile'),
            //     'default'    => '',
            // ),

        ),
    )
);


        