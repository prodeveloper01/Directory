<?php

azp_add_element(
    'app_banner',
    array(
        'name'                    => __('Image Banner', 'easybook-mobile'),
        'category'                => 'Mobile App',
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => false,
        'showTypographyTab'       => false,
        'showAnimationTab'        => false,
        'template_folder'         => 'apps/',
        'is_section'              => true,
        'attrs'                   => array(
            // array(
            //     'type'       => 'text',
            //     'param_name' => 'title',
            //     'label'      => __('Title', 'easybook-mobile'),
            //     // 'desc'                  => '',
            //     'default'    => '',
            // ),


            array(
                'type'          => 'image',
                'param_name'    => 'src',
                'label'         => __('Banner Image', 'easybook-mobile'),
                // 'show_in_admin' => true,
                'desc'          => '',
                'default'       => '',
            ),

            array(
                'type'          => 'text',
                'param_name'    => 'width',
                'label'         => __('Banner Width', 'easybook-mobile'),
                // 'desc'                  => '',
                'default'       => '',
            ),

            array(
                'type'          => 'text',
                'param_name'    => 'height',
                'label'         => __('Banner Height', 'easybook-mobile'),
                // 'desc'                  => '',
                'default'       => '150',
            ),

            array(
                'type'          => 'text',
                'param_name'    => 'url',
                'label'         => __('Banner Link URL', 'easybook-mobile'),
                // 'desc'                  => '',
                'default'       => '',
            ),

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_id',
            //     'label'      => __('Element ID', 'easybook-mobile'),
            //     // 'desc'                  => '',
            //     'default'    => '',
            // ),

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_class',
            //     'label'      => __('Extra Class', 'easybook-mobile'),
            //     'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-mobile'),
            //     'default'    => '',
            // ),

        ),
    )
);
